0. dataimport

The function to import and clean the data.

1. factors : factor data

2. port_3x2 : bivaraite-sorted

3. port_5x5 : bivaraite-sorted

4. port202 : 202 downloaded portfolios

5. summary : the summary information for all 150 factors

6. port_3x2_id : the minimum number of stocks in a portfolio for each factor, for port_3x2

7. port_5x5_id : the minimum number of stocks in a portfolio for each factor, for port_5x5